// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDv29lPKgpQtCKZ6IPaiDXQDZ7EDxiC02c",
  authDomain: "logginapp-8ed3e.firebaseapp.com",
  projectId: "logginapp-8ed3e",
  storageBucket: "logginapp-8ed3e.firebasestorage.app",
  messagingSenderId: "818638337064",
  appId: "1:818638337064:web:1874ba471020714983711d"
};

// Initialize Firebase
export default app = initializeApp(firebaseConfig);